<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\NagpurController;
use App\Http\Controllers\MaharastraController;
use App\Http\Controllers\NationalController;
use App\Http\Controllers\CrimeController;
use App\Http\Controllers\EntertainmentController;
use App\Http\Controllers\PoliticsController;
use App\Http\Controllers\SportsController;
use App\Http\Controllers\NewNagpurController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/',[HomeController::class,'index'])->name('/');
Route::get('nagpur',[NagpurController::class,'index'])->name('nagpur');
Route::get('maharastra',[MaharastraController::class,'index'])->name('maharastra');
Route::get('national',[NationalController::class,'index'])->name('national');
Route::get('crime',[CrimeController::class,'index'])->name('crime');
Route::get('entertainment',[EntertainmentController::class,'index'])->name('entertainment');
Route::get('politics',[PoliticsController::class,'index'])->name('politics');
Route::get('sports',[SportsController::class,'index'])->name('sports');
Route::get('nagpurnew',[NewNagpurController::class,'index'])->name('nagpurnew');
