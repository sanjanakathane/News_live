<style>
  .footer-bottom-area{
    background-color: black
  }
  .email_subscipton {
    padding: 0.5rem 1rem;
    color: #fff;
    font-weight: 400;
  }
  .footer-bottom-area .footer-copy-right p {
    color: #838383;
    font-weight: 300;
    font-size: 16px;
    line-height: 2;
    margin-bottom: 0px;
  }
  .footer-menu ul{
      list-style: none;
  }
  .footer-menu ul li {
    display: inline-block;
  }
</style>
  <footer>
    <!-- footer-bottom aera -->
    <div class="footer-bottom-area">
        <div class="container">
            <div class="footer-border">
                <div class="row d-flex align-items-center col-sm-12 col-md-12">

                    <div class="col-md-2 col-6 d-flex justify-items-center">
                        <img class="w-100 py-3 px-2 mb-2" src="images/footer.png" alt="">
                    </div>
                    <div class="col-md-10 email_subscipton">
                        <form action="/emailSubsciption" method="post" class="row">
                        
                            <div class="col-md-4">Subscribe Get the latest news from UCN NEWS in your inbox.</div>
                            <div class="col-md-4"><input required="" name="email" placeholder="Enter Your Mail" type="email" value=""></div>
                                    
                            <div class="col-md-3">
                                <button type="submit">Subscribe</button>
                            </div>
                        </form>
                    </div>
                    <div class="col-lg-6">
                        <div class="footer-copy-right">
                            <p>
                                Copyright ©
                                <script>
                                    document.write(new Date().getFullYear());
                                </script>2023 All rights reserved
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="footer-menu f-right ">
                            <ul>
                                <li><a href="">About Us &amp; Contact</a></li>
                                <li><a href="">Privacy Policy</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End-->
    <div id="scroll_up_button" class="scroll_up_button" style="display: flex;">
        <ion-icon onclick="scrollUpPage()" name="arrow-up-circle-outline" role="img" class="md hydrated" aria-label="arrow up circle outline"></ion-icon>
    </div>
    
        

</footer>
</body>
</html><?php /**PATH C:\xampp\htdocs\UcnNewsLive\resources\views/layouts/footer.blade.php ENDPATH**/ ?>