<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link rel="stylesheet" href="css/home.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
</head>

<body>
<div class="container-fluid">
	<div class="row" style="background-color: lightblue;">
		<div class="col-md-4">
			<img alt="" src="images/logo.png"  class="img-fluid" />
		</div>
		<div class="col-md-8">
    </div>
	</div>


  <div class="row bg-primary h-auto">
    <div class="col-12">
    <div class="navbar bg-primary justify-content-center  ">
          <ul>
              <li><a href="{{route('/')}}" >Home</a></li>
              <li><a href="{{route('nagpur')}}">नागपुर</a></li>
              <li class="dropdown">
                <a >विदर्भ  </a>
                <div class="dropdown-content">
                 <a class="dropdown-item" href="#">अकोला</a>
                 <a class="dropdown-item" href="#">अमरावती </a>
                  <a class="dropdown-item" href="#">भंडारा </a>
		              <a class="dropdown-item" href="#">बुलढाणा </a>
		              <a class="dropdown-item" href="#">चंद्रपुर </a>
		              <a class="dropdown-item" href="#">गोंदिया </a>
		              <a class="dropdown-item" href="#">गडचिरोली </a>
		              <a class="dropdown-item" href="#">वर्धा </a>
		              <a class="dropdown-item" href="#">वाशिम </a>
                </div>
             </li>
             <li><a href="{{route('maharastra')}}">महाराष्ट्र</a></li>
             <li><a href="{{route('national')}}">राष्ट्रीय</a></li>
             <li><a href="{{route('crime')}}">क्राइम</a></li>
             <li><a href="{{route('entertainment')}}">एंटरटेनमेंट</a></li>
             <li><a href="{{route('politics')}}">राजनीति</a></li>
             <li><a href="{{route('sports')}}">स्पोर्ट्स</a></li>
           </ul>
    </div>
    </div>
  </div>

	
	
	<div class="contan d-flex flex-row margin-left: -30px;" style=" height:40px">
		<div class="col-md-3 bg-danger text-center text-light" style="width: 100px; height: 100%; ">
				Breaking
		</div>
		<div class="col-md-9">
			
		</div>
	</div>
	<div class="liveChannelsBar row d-flex justify-content-center">
            <a class="col-4  col-md-3 " href="" style="background-image: url('images/img1.png')">
               <span class="me-2">UCN News</span>
            </a>
            <div class="col-4  col-md-3 d-flex" style="background-image: url('images/img2.png')">
             <ul class="navbar-nav">
		          <li class="nav-item dropdown">
                  <a class="nav-link justify-content-center align-items-center" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
		         <span style="color: yellow; text-align:center;"> UCN Entertainment</span>
                  </a>
               <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                 <a class="dropdown-item" href="#">UCN Prime</a>
                 <a class="dropdown-item" href="#">UCN Pub  </a>
                 <a class="dropdown-item" href="#">UCN Shraddha </a>
               </div>
              </li>
           </ul>
          </div>
        <a class="col-4  col-md-3" href="" style="background-image: url('images/last.png')">
            <span class="me-2">UCN INFO</span>
        </a>
      </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js" integrity="sha384-fbbOQedDUMZZ5KreZpsbe1LCZPVmfTnH7ois6mU1QK+m14rQ1l2bGBq41eYeM/fS" crossorigin="anonymous"></script>