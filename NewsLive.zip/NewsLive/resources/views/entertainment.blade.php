{{-- @extends('layouts.main')
@section('main-container')

<div class="row gx-5 gy-10" style="margin-top:10px; ">
<div class="col-lg-2 d-none d-lg-block">
       <img alt="" src="images/img4.png" class="img-fluid" />
    </div>
            
    <div class="col-md-4 col-sm-12 col-lg-4 col-md-12 ">
      <div class="row bannerSection">
         <div id="carouselExampleIndicators" class="carousel slide carousel-dark">
            <div class="carousel-inner">
                <div class="carousel-item active ">
                    <img src="images/img5.jpg" class="d-block w-100" style="margin-top:10px" alt="..." >
                      <div class="caption">
                           <h3>Lorem ipsum dolor sit amet consectetur adipisicing elit. Earum accusamus minima praesentium ad</h3>
                      </div>
                      <span class="postedTime">Jun 20 2023 - 08:13 PM</span>
                </div>
                <div class="carousel-item">
                    <img src="images/img6.jpg" class="d-block w-100" alt="...">
                      <div class="caption">
                           <h3>Lorem ipsum dolor sit amet consectetur adipisicing elit. Earum accusamus minima praesentium ad</h3>
                      </div>
                      <span class="postedTime">Jun 20 2023 - 08:13 PM</span>
                </div>
                <div class="carousel-item">
                    <img src="images/img7.jpg" class="d-block w-100" alt="...">
                      <div class="caption">
                           <h3>Lorem ipsum dolor sit amet consectetur adipisicing elit. Earum accusamus minima praesentium ad</h3>
                      </div>
                      <span class="postedTime">Jun 20 2023 - 08:13 PM</span>
                </div>
            </div>
          </div>
          <!-- <div class="carousel-indicators">
               <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
               <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
               <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
          </div> -->
          <div class="sideBarFirst">
               <div class="imgWrapper">
                   <img src="images/img5.jpg" alt="" class="img-fluid">
                </div>
               <div class="sidecaption" >
                  <h3> Lorem ipsum dolor sit amet consectetur adipisicing elit. Exercitationem, quis!</h3>
                  <span class="postedTime">Jun 20 2023 - 02:37 PM</span>
               </div>
          </div>
      </div>
    </div>
    
    <div class="col-xxl-4 col-lg-4">
              <div class="sideBarSection row">
              <div class="eachItem col-lg-12 col-md-6 col-12 p-1">
                          <div class="row eachrow">
                            <div class="col-md-4 d-flex align-items-center">
                                <div class="imgWrapper">
                                    <img src="images/img5.jpg"  class="img-fluid"alt="">
                                </div>
                            </div>
                            <div class="col-md-8">
                                <h3> Video: दोस्तों के साथ जन्मदिन मना रहा था युवक, लेकिन हुआ कुछ ऐसा कि, जान पर बन आई </h3>
                                <span class="postedTime">Jun 20 2023 - 05:34 PM</span>
                            </div>
                          </div>
                    </div>
                    <div class="eachItem col-lg-12 col-md-6 col-12 p-1 g-2">
                        <div class="row eachrow">
                            <div class="col-md-4 d-flex align-items-center">
                                <div class="imgWrapper">
                                    <img src="images/img5.jpg" class="img-fluid" alt="Washim: पुलिस को कामयाबी, बस पर पथराव करनेवाले तीन आरोपी गिरफ्तार">
                                </div>
                            </div>
                            <div class="col-md-8">
                                <h3> Washim: पुलिस को कामयाबी, बस पर पथराव करनेवाले तीन आरोपी गिरफ्तार </h3>
                                <span class="postedTime">Jun 20 2023 - 08:21 PM</span>
                            </div>
                        </div>
                    </div>
                    <div class="eachItem col-lg-12 col-md-6 col-12 p-1 g-2">
                          <div class="row eachrow">
                            <div class="col-md-4 d-flex align-items-center">
                                <div class="imgWrapper">
                                    <img src="images/img5.jpg"  class="img-fluid"alt="">
                                </div>
                            </div>
                            <div class="col-md-8">
                                <h3> Video: दोस्तों के साथ जन्मदिन मना रहा था युवक, लेकिन हुआ कुछ ऐसा कि, जान पर बन आई </h3>
                                <span class="postedTime">Jun 20 2023 - 05:34 PM</span>
                            </div>
                          </div>
                    </div>
                    <div class="eachItem col-lg-12 col-md-6 col-12 p-1 g-2">
                        <div class="row eachrow">
                            <div class="col-md-4 d-flex align-items-center">
                                <div class="imgWrapper">
                                    <img src="images/img5.jpg" class="img-fluid" alt="Washim: पुलिस को कामयाबी, बस पर पथराव करनेवाले तीन आरोपी गिरफ्तार">
                                </div>
                            </div>
                            <div class="col-md-8">
                                <h3> Washim: पुलिस को कामयाबी, बस पर पथराव करनेवाले तीन आरोपी गिरफ्तार </h3>
                                <span class="postedTime">Jun 20 2023 - 08:21 PM</span>
                            </div>
                        </div>
                    </div>
             </div>
    </div>
        
    <div class="col-12 col-md-2 d-md-block">
        <img alt="Bootstrap Image Preview" src="images/img4.png" class="img-fluid w-100 medium-image " />
    </div> 
    </div>
    
    <div class="col-md-12 col-12 d-flex align-items-center p-2">
        <div class="recentSection row mx-3">
            <div class="eachItem dashedBelow col-lg-4 col-md-4 p-1 g-2">
                <div class="row">
                      <div class="col-md-4 d-flex align-items-center px-0">
                          <div class="imgWrapper">
                              <img src="images/img5.jpg" class="img-fluid">
                          </div>
                      </div>
                      <div class="col-md-8">
                                <h3> रामलला इस दिन विराजेंगे, अयोध्या में बन रहे मंदिर के उद्घाटन की तारीख आई सामने </h3>
                                <span class="postedTime">Jun 20 2023 - 02:25 PM</span>
                      </div>
                </div>
              </div>
              <div class="eachItem dashedBelow col-lg-4 col-md-4 p-1 g-2">
                <div class="row">
                      <div class="col-md-4 d-flex align-items-center px-0">
                          <div class="imgWrapper">
                              <img src="images/img5.jpg" class="img-fluid">
                          </div>
                      </div>
                      <div class="col-md-8">
                                <h3> रामलला इस दिन विराजेंगे, अयोध्या में बन रहे मंदिर के उद्घाटन की तारीख आई सामने </h3>
                                <span class="postedTime">Jun 20 2023 - 02:25 PM</span>
                      </div>
                </div>
              </div>
              <div class="eachItem dashedBelow col-lg-4 col-md-4 p-1 g-2">
                <div class="row">
                      <div class="col-md-4 d-flex align-items-center px-0">
                          <div class="imgWrapper">
                              <img src="images/img5.jpg" class="img-fluid">
                          </div>
                      </div>
                      <div class="col-md-8">
                                <h3> रामलला इस दिन विराजेंगे, अयोध्या में बन रहे मंदिर के उद्घाटन की तारीख आई सामने </h3>
                                <span class="postedTime">Jun 20 2023 - 02:25 PM</span>
                      </div>
                </div>
              </div>
              <div class="eachItem dashedBelow col-lg-4 col-md-4 p-1 g-2">
                <div class="row">
                      <div class="col-md-4 d-flex align-items-center px-0">
                          <div class="imgWrapper">
                              <img src="images/img5.jpg" class="img-fluid">
                          </div>
                      </div>
                      <div class="col-md-8">
                        <h3> रामलला इस दिन विराजेंगे, अयोध्या में बन रहे मंदिर के उद्घाटन की तारीख आई सामने </h3>
                         <span class="postedTime">Jun 20 2023 - 02:25 PM</span>
                      </div>
                </div>
              </div>
              <div class="eachItem dashedBelow col-lg-4 col-md-4 p-1 g-2">
                <div class="row">
                      <div class="col-md-4 d-flex align-items-center px-0">
                          <div class="imgWrapper">
                              <img src="images/img5.jpg" class="img-fluid">
                          </div>
                      </div>
                      <div class="col-md-8">
                          <h3> रामलला इस दिन विराजेंगे, अयोध्या में बन रहे मंदिर के उद्घाटन की तारीख आई सामने </h3>
                          <span class="postedTime">Jun 20 2023 - 02:25 PM</span>
                      </div>
                </div>
              </div>                                
              <div class="eachItem dashedBelow col-lg-4 col-md-4 p-1 g-2">
                <div class="row">
                      <div class="col-md-4 d-flex align-items-center px-0">
                          <div class="imgWrapper">
                              <img src="images/img5.jpg" class="img-fluid">
                          </div>
                      </div>
                      <div class="col-md-8">
                          <h3> रामलला इस दिन विराजेंगे, अयोध्या में बन रहे मंदिर के उद्घाटन की तारीख आई सामने </h3>
                          <span class="postedTime">Jun 20 2023 - 02:25 PM</span>
                      </div>
                </div>
              </div>                                   
              <div class="eachItem dashedBelow col-lg-4 col-md-4 p-1 g-2">
                <div class="row">
                      <div class="col-md-4 d-flex align-items-center px-0">
                          <div class="imgWrapper">
                              <img src="images/img5.jpg" class="img-fluid">
                          </div>
                      </div>
                      <div class="col-md-8">
                          <h3> रामलला इस दिन विराजेंगे, अयोध्या में बन रहे मंदिर के उद्घाटन की तारीख आई सामने </h3>
                          <span class="postedTime">Jun 20 2023 - 02:25 PM</span>
                      </div>
                </div>
              </div>
              <div class="eachItem dashedBelow col-lg-4 col-md-4 p-1 g-2">
                <div class="row">
                      <div class="col-md-4 d-flex align-items-center px-0">
                          <div class="imgWrapper">
                              <img src="images/img5.jpg" class="img-fluid">
                          </div>
                      </div>
                      <div class="col-md-8">
                          <h3> रामलला इस दिन विराजेंगे, अयोध्या में बन रहे मंदिर के उद्घाटन की तारीख आई सामने </h3>
                          <span class="postedTime">Jun 20 2023 - 02:25 PM</span>
                      </div>
                </div>
              </div>                                   
              <div class="eachItem dashedBelow col-lg-4 col-md-4 p-1 g-2">
                <div class="row">
                      <div class="col-md-4 d-flex align-items-center px-0">
                          <div class="imgWrapper">
                              <img src="images/img5.jpg" class="img-fluid">
                          </div>
                      </div>
                      <div class="col-md-8">
                         <h3> रामलला इस दिन विराजेंगे, अयोध्या में बन रहे मंदिर के उद्घाटन की तारीख आई सामने </h3>
                          <span class="postedTime">Jun 20 2023 - 02:25 PM</span>
                      </div>
                </div>
              </div>                                 
             <h3 class="header">ताजा खबरें</h3>
             <a class="viewMoreBtn" href=""><span>View More</span></a>
        </div>
    </div>
    <div class="row">
      <div class="col-12">
        <img src="images/img8.png" alt="" style="width: 100%">
      </div> 
    </div>

    <div class="tabbable boxed parentTabs p-4">
        <ul class="nav nav-tabs">
            <li class="active"><a href="#set1" class="nav-link">विदर्भ</a>
            </li>
            <li><a href="#set2" class="nav-link">महाराष्ट्र</a>
            </li>
        </ul>
        <div class="tab-content ">
            <div class="tab-pane fade active show" id="set1">
                <div class="tabbable">
                    <ul class="nav nav-tabs">
                        <li class="active"><a href="#sub11" class="nav-link">नागपुर</a>
                        </li>
                        <li><a href="#sub12" class="nav-link">अकोला</a>
                        </li>
                        <li><a href="#sub13" class="nav-link">अमरावती</a>
                        </li>
                        <li><a href="#sub14" class="nav-link">भंडारा</a>
                        </li>
                        <li><a href="#sub15" class="nav-link">बुलढाणा</a>
                        </li>
                        <li><a href="#sub16" class="nav-link">चंद्रपुर</a>
                        </li>
                        <li><a href="#sub17" class="nav-link">गोंदिया</a>
                        </li>
                        <li><a href="#sub18" class="nav-link">गडचिरोली</a>
                        </li>
                        <li><a href="#sub19" class="nav-link">वर्धा</a>
                        </li>
                        <li><a href="#sub20" class="nav-link">वाशिम</a>
                        </li>
                        <li><a href="#sub21" class="nav-link">यवतमाल</a>
                        </li>
                    </ul>
                    <div class="tab-content">
                        <div class="tab-pane fade active show" id="sub11">
                            
                        </div>
                        <div class="tab-pane fade" id="sub12">
                            <p>akola</p>
                        </div>
                        <div class="tab-pane fade" id="sub13">
                          <p>amravti</p>
                        </div>
                        <div class="tab-pane fade" id="sub14">
                        <p>bhandara</p>
                        </div>
                        <div class="tab-pane fade" id="sub15">
                          <p>buldhana</p>
                        </div>
                       <div class="tab-pane fade" id="sub16">
                         <p>chnadrapur</p>
                        </div>
                        <div class="tab-pane fade" id="sub17">
                          <p>gondia</p>
                      </div>
                      <div class="tab-pane fade" id="sub18">
                        <p>gadchiroli</p>
                      </div>
                      <div class="tab-pane fade" id="sub19">
                      <p>wardha</p>
                      </div>
                      <div class="tab-pane fade" id="sub20">
                        <p>washim</p>
                      </div>
                     <div class="tab-pane fade" id="sub21">
                       <p>yavalmal</p>
                     </div>
                  </div>
                </div>
            </div>
            <div class="tab-pane fade" id="set2">
                <div class="tabbable">
                    <ul class="nav nav-tabs">
                        <li class="active"><a href="#sub21" class="nav-link">PopularBrands</a>
                        </li>
                        <li><a href="#sub22" class="nav-link">UniqueBrands</a>
                        </li>
                    </ul>
                    <div class="tab-content">
                        <div class="tab-pane fade active in" id="sub21">
                            <p>pop brand content</p>
                        </div>
                        <div class="tab-pane fade" id="sub22">
                            <p>unique brand content</p>
                        </div>
                    </div>
                </div>
            </div>
           
        </div>
    </div>




<script>
  $("ul.nav-tabs a").click(function (e) {
  e.preventDefault();  
    $(this).tab('show');
});
</script>
@endsection

 --}}
