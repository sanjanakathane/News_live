<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class MaharastraController extends Controller
{
    //
    public function index(){
        return view('maharastra');
    }
}
